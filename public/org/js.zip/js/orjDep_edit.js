
//全局变量
var products = [] , orgTreeData = [];
var ORGID='',  selectedDeptID='';

$(
//加载后获取org tree数据源

function() {

var id = GetQueryString('id');
if(!id) {alert('ID数据不正确，数据获取失败');  return ;} 
ORGID = id;

get_OrgTree(id) 

}); // function end  //  $() end  


//获取组织树形数据，并网页初始化
function get_OrgTree(id) {

var data = {};
var orgID = id;
console.log(orgID);

data.orgID = orgID;
if(!data.orgID) {alert('ID数据不正确，数据获取失败');  return ;} 

console.log(data);
$.post('/org/Ajax_getOrgTree', data ,

function(dataBack) {
    if(dataBack.status == '404') {alert('数据获取失败。'); console.log(dataBack.des) ;return ;} 
   
    if(dataBack.status == '200') {
      orgTreeData = dataBack.docData;
      console.log(orgTreeData);
      //初始化Org 树形列表
      onloadTree(orgTreeData);

    } //if end

 }); //function end   //.post end
}





//初始化Org 树形列表
function onloadTree(datas) {

    var tree_data = new kendo.data.TreeListDataSource({

    //{ orgId: 1, orgShortDes: "武汉理工大学",  parentId: null },
    //{ orgId: 2, orgShortDes: "计算机学院", parentId: 1 },
        data: datas   ,
        schema: {
        model: {
            id: "orgID",
            expanded: true
        }
        }
    });

    $("#treelist").kendoTreeList({
        dataSource: tree_data,
        height : 510,
        columns: [
            { 
              //field: "orgFullDes",
              template: " <a id='node_#=orgID#' class='treeNode' oid='#=orgID#'  onclick='onSelectedOrg(this)'  > #=orgFullDes# </a> " ,  
              expandable: false, title: "", width: 80 
        },
        ]
    });


}


//机构子结点被选中后。。。: 1.改变背景颜色， 2.改变全局变量：选中的机构ID.
function onSelectedOrg(ele) {
  var oid = ele.getAttribute('oid');
  $('a.treeNode').css("background-color","white");
  $(ele).css("background-color","#00ff00");
  selectedDeptID =  oid;
  //alert(selectedDeptID);
}







//'添加下级'按钮被按下
$("#addChild").click(function() {
  //alert('添加下级');
  var deptDes = $('#deptDes').val();
  deptDes =  deptDes.trim();
  if(selectedDeptID == '') {alert('请选中一个机构.');  return;}
  if(deptDes == '' )  {alert('机构名称不能为空!');  $('#deptDes', this.el).focus(); return ;}
 
  //如果机构名称不为空， 后台增加机构数据， 父节点数据暂时伪造
  var parentId = selectedDeptID;
  var data={};
  data.deptDes = deptDes; 
  data.parentId = parentId;
  data.orgID = ORGID;

  Ajax_addDept(data);  

});



//'增加同级'按钮被按下
$("#addPeer").click(function() {
  //alert('添加同级');
  var deptDes = $('#deptDes').val();
  deptDes =  deptDes.trim();
  if(selectedDeptID == '') {alert('请选中一个机构.');  return;}
  if(deptDes == '' )  {alert('机构名称不能为空!');  $('#deptDes', this.el).focus(); return ;}
 
  //如果机构名称不为空， 后台增加机构数据， 父节点数据暂时伪造
  var parentId = "9abfb0c0-5303-11e6-af2d-358a86764e4c";
  var data={};
  data.deptDes = deptDes; 
  data.parentId = parentId;
  data.orgID = ORGID;

  Ajax_addDept(data);  

});




//后台添加机构
function Ajax_addDept(data) {
    $.post('/org/Ajax_addDept', data ,

        function(dataBack) {
            if(dataBack.status == '404') {alert('机构添加失败。'); console.log(dataBack.des) ;return ;} 

            if(dataBack.status == '200') {
                //更新组织树形结构
                get_OrgTree(GetQueryString('id'));

            } //if end

        }); //function end   //.post end   

}



//'新增'按钮被点击后，弹出选择用户的界面
$("#addUser").click(function() {
  //alert('添加同级');
  var deptDes = $('#deptDes').val();
  deptDes =  deptDes.trim();
  if(selectedDeptID == '') {alert('请选中一个机构.');  return;}
  if(deptDes == '' )  {alert('机构名称不能为空!');  $('#deptDes', this.el).focus(); return ;}
 
  //如果机构名称不为空， 后台增加机构数据， 父节点数据暂时伪造
  var parentId = "9abfb0c0-5303-11e6-af2d-358a86764e4c";
  var data={};
  data.deptDes = deptDes; 
  data.parentId = parentId;
  data.orgID = ORGID;

  Ajax_addDept(data);  

});



//'重置'按钮被点击后，弹出选择用户的界面
$("#userSet").click(function() {
    $('#uid').val('');
    $('#displayname').val('');
    $('#email').val('');
});



//'查询'按钮被点击后，弹出选择用户的界面
$("#userSearch").click(function() {
    var uid = $('#uid').val();
    var displayname = $('#displayname').val();
    var email = $('#email').val();
    uid = uid.trim(); displayname = displayname.trim();  email = email.trim();
    if(uid == '' && displayname == '' &&  email == '' )  {alert('查询条件，不能全为空。'); return;}
    
    //初始化data， 并请求后台数据
    var data = {};
    data.uid = uid;  data.displayname = displayname;  data.email = email;
    //获取User信息
    Ajax_searchUsers(data); 
   
});


//获取User信息
function Ajax_searchUsers(data) {
    
        $.post('/org/Ajax_searchUsers', data ,

        function(dataBack) {
            if(dataBack.status == '404') {alert('机构添加失败。'); console.log(dataBack.des) ;return ;} 

            if(dataBack.status == '200') {
                //更新组织树形结构
                alert('OK');
               // get_OrgTree(GetQueryString('id'));

            } //if end

        }); //function end   //.post end   


}



 
 
               $(document).ready(function () {
                    var dataSource = new kendo.data.DataSource({
                       pageSize: 20,
                       data: products,
                       autoSync: true,
                       schema: {
                           model: {
                             id: "ProductID",
                             fields: {
                                ProductID: { editable: false, nullable: true },
                                ProductName: { validation: { required: true } },
                                Category: { defaultValue: { CategoryID: 1, CategoryName: "Beverages"} },
                                UnitPrice: { type: "number", validation: { required: true, min: 1} }
                             }
                           }
                       }
                    });


                     

                    $("#grid").kendoGrid({
                        dataSource: dataSource,
                        pageable: true,
                        height: 550,
                        toolbar: ["create", "save"],
                        columns: [
                            { field:"",title:"用户账号", width: "100px" },
                            { field: "Category", title: "昵称", width: "100px", editor: categoryDropDownEditor, template: "#=Category.CategoryName#" },
                            { field: "UnitPrice", title:"姓名",  width: "80px" },
                            { field:"",title:"性别", width: "70px" },                            
                            { field:"",title:"联系电话", width: "120px" },                            
                            { field:"",title:"家庭地址", width: "150px" },   

                            { command: "destroy", title: "操作", width: "100px" }],
                        editable: true
                    });
                   



                });

                function categoryDropDownEditor(container, options) {
                    $('<input required data-text-field="CategoryName" data-value-field="CategoryID" data-bind="value:' + options.field + '"/>')
                        .appendTo(container)
                        .kendoDropDownList({
                            autoBind: false,
                            dataSource: {
                                type: "odata",
                                transport: {
                                    read: "//demos.telerik.com/kendo-ui/service/Northwind.svc/Categories"
                                }
                            }
                        });
                }



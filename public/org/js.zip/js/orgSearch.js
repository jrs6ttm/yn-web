


$(document).ready(function () {


});



var orders =[];

//设置Grid数据
function SetGrid(data) {
        $("#singleSort").kendoGrid({
            dataSource: {
                data: data,
                pageSize: 7
            },
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            pageable: {
                buttonCount: 5
            },
            scrollable: false,
            columns: [ 
               
                {
                    field: "orgCode",
                    title: "组织代码",
                    width: 100
                },
                {
                    field: "orgFullDes",
                    title: "组织名称",                    
                    width: 150
                },

            {
                    field: "orgShortDes",
                    title: "组织简称",                    
                    width: 100
                },


            {
                    template: "<a  href='/org/org_edit?id=#=orgID#' >维护信息</a>   <a  href='/org/orgDep_edit?id=#=orgID#'  >维护机构</a>",
                    title: "操作",                      
                    width: 150
                },

            {       
                    field: "orgSort",
                    title: "组织类型", 
                    width: 100
                },

            {
                    field: "schoolType",
                    title: "是否学校类型", 
                    width: 100
                },

            {
                    field: "REMARK",
                    title: "备注",
                    width: 90
                },
            ]
        });
}



// 清除两边的空格 
String.prototype.trim = function() { 
  return this.replace(/(^\s*)|(\s*$)/g, ''); 
}; 



//组织查询列表中‘查询’按钮---list符合条件的组织
  $("#org_search_search").click(function(){
      var orgCode = $('#orgCode').val().trim();  
      var orgFullDes = $('#orgFullDes').val().trim(); 
      var orgShortDes = $('#orgShortDes').val().trim(); 
      var remark = $('#remark').val().trim(); 
     
      if(orgCode ==''  && orgFullDes ==''   && orgShortDes==''   && remark=='' )  { alert('查询条件不能全部为空！');  return ;}
      
      var data={};
      data.orgCode = orgCode;
      data.orgFullDes = orgFullDes;
      data.orgShortDes = orgShortDes;   
      data.remark = remark;  
     
      console.log(data);

      //*****AJAX查询组织信息并显示到列表
      searchOrg(data);
      
  });

//*****AJAX查询组织信息并显示到列表
function searchOrg(data) {

 $.post("/org/Ajax_searchOrg",  data  ,

  function(dataBack){
    if(dataBack.status == '404') {alert('查询操作失败'); return ;} 
   
    if(dataBack.status == '200') {
      //console.log(dataBack.docData);
     // alert('查询成功');
       var resDatas = dataBack.docData;
       var t1 , t2;
       for(i=0; i< resDatas.length ; i++) {
           t1 =  resDatas[i].orgSort;
           t2 =  resDatas[i].schoolType;
           //解析组织类型
           if(t1 == 0)   resDatas[i].orgSort = '非正式组织';
           if(t1 == 1)   resDatas[i].orgSort = '正式组织';          
           if(t1 == 2)   resDatas[i].orgSort = '临时组织';
           if(t1 == 3)   resDatas[i].orgSort = '其它';    

           //解析学校结构
           if(t2 == 0)   resDatas[i].schoolType= '否';
           if(t2 == 1)   resDatas[i].schoolType = '是';          

       }
       SetGrid(dataBack.docData);
    
       console.log(dataBack.docData);

      //orders = dataBack.docData;

    }

  });  //ajax end

}



//组织查询列表中‘重置’按钮
  $("#org_search_reSet").click(function(){
      $('#orgCode').val('');  
      $('#orgFullDes').val(''); 
      $('#orgShortDes').val(''); 
      $('#remark').val(''); 
  });

//组织查询列表中‘新增组织’按钮
  $("#org_search_addOrg").click(function(){
      var url = "/org/org_edit" ;
      window.location.href=url;
  });


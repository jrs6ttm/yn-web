


//组织机构编辑中保存按钮---添加或保存组织信息
  $("#save").click(function(){
    var orjID =  $('#orjID').val();
    orjID = orjID.trim();
    console.log(orjID);

    var dateTime= new Date().Format("yyyy-MM-dd HH:mm:ss");  

    var data = {};

    data.orgCode = $('#orgCode').val();
    data.legalPerson = $('#legalPerson').val();
    data.orgFullDes = $('#orgFullDes').val();
    data.tel1 = $('#tel1').val();
    data.orgShortDes = $('#orgShortDes').val();
    data.orgSort = $('#orgSort').val();
    data.emailAdress = $('#emailAdress').val();
    data.tel2 = $('#tel2').val();
    data.address = $('#address').val();
    data.schoolType = $('#schoolType').val();
    data.orgscaleType = $('#orgscaleType').val();
    data.registerMoney = $('#registerMoney').val();
    data.businessLicense = $('#businessLicense').val();
    data.REMARK = $('#REMARK').val();
    data.ISVALID = 0; 

    console.log(data);


    //如果为空，表示第一次添加，插入orj数据. 
    if(orjID == '' )   insertOrj(data);
    else  //如果不为空，则检查数据是否存于数据库， 如果存在，更新。
      {  data.orgID = orjID;saveOrj( data);  } 

   });


//组织机构编辑中'提交生效'按钮---提交组织信息
  $("#OKsumbit").click(function(){
    var orjID =  $('#orjID').val();
    orjID = orjID.trim();
    console.log(orjID);

    var dateTime= new Date().Format("yyyy-MM-dd HH:mm:ss");  

    var data = {};

    data.orgCode = $('#orgCode').val();
    data.legalPerson = $('#legalPerson').val();
    data.orgFullDes = $('#orgFullDes').val();
    data.tel1 = $('#tel1').val();
    data.orgShortDes = $('#orgShortDes').val();
    data.orgSort = $('#orgSort').val();
    data.emailAdress = $('#emailAdress').val();
    data.tel2 = $('#tel2').val();
    data.address = $('#address').val();
    data.schoolType = $('#schoolType').val();
    data.orgscaleType = $('#orgscaleType').val();
    data.registerMoney = $('#registerMoney').val();
    data.businessLicense = $('#businessLicense').val();
    data.REMARK = $('#REMARK').val();
    data.ISVALID = 1; 

    console.log(data);


    //如果为空，表示第一次添加，插入orj数据. 
    if(orjID == '' )   insertOrj(data,1);
    else  //如果不为空，则检查数据是否存于数据库， 如果存在，更新。
      {  data.orgID = orjID;saveOrj(data,1);  } 

   });




//插入组织数据, flag为1表示被提交生效调用
function  insertOrj(data, flag)
{
 $.post("/org/Ajax_insertOrj",  data  ,

  function(dataBack){
    if(dataBack.status == '404') {alert('Ajax操作失败'); return ;} 
   
    if(dataBack.status == '200') {
      //console.log(dataBack.docData);
      
      //对orjID赋值
      $('#orjID').val(dataBack.docData.orgID);
     
      if(flag == 1)   alert('已经生效');
      else
         alert('保存成功');
    }

  });  //ajax end

}

//更新组织数据 , flag为1表示被提交生效调用
function saveOrj(data,flag)
{
 $.post("/org/Ajax_updateOrj",  data  ,

  function(dataBack){
    if(dataBack.status == '404') {alert('Ajax操作失败:' + dataBack.des ); return ;} 
   
    if(dataBack.status == '200') {
      if(flag == 1)   alert('已经生效');
      else
         alert('保存成功');
    }

  });  //ajax end
}




//组织机构编辑中'返回组织列表页'按钮
  $("#toOrgList").click(function(){
      var url = "/org/org_search"  ;
      window.location.href=url;

  });



//Ajax修改模板： table: 表名 ， update_txt:修改字段，  where_txt ：条件语句 
function update_myExamOK(data) {
// 发送AJAX 修改指定数据
  console.log(data);

 $.post("/exam/Ajax_update_txt_V2",
  {
    'table': data.table  ,
    'update_txt' :  data.update ,
    'where_txt' :  data.where
  },


     // res.send({examID:doc_exam.insertId , pageID: doc_page.insertId , status : '200'}); 
  function(dataBack){
    //alert("Data: " + data.examID + ',' + data.pageID + "\nStatus: " + data.status);
    if(dataBack.status == '404') {alert('Ajax操作失败'); return ;} 
   
    if(dataBack.status == '200') {

      var url = "/exam/myExamOK?" + "myexamid=" + data.myexamid ;
      window.location.href=url;
    }

  });  //ajax end

}



